# 🧩 Sistema de Gerenciamento de Animais do Zoológico (Java OOP)

Este projeto demonstra **encapsulamento**, **herança**, **polimorfismo**, **interfaces** e **sobrecarga** em Java,
seguindo os requisitos do exercício.

## ⚙️ Como compilar e executar (sem IDE)

Requisitos: JDK 11+ instalado e `javac` no PATH.

```bash
# 1) Vá até a pasta do projeto
cd zoologico-java

# 2) Compile todos os .java gerando os .class em ./out
mkdir -p out
javac -d out src/zoo/interfaces/*.java src/zoo/*.java

# 3) Execute o programa principal
cd out
java zoo.Zoologico
```

## 📂 Estrutura
```
zoologico-java/
├─ README.md
└─ src/
   └─ zoo/
      ├─ interfaces/
      │  └─ Alimentavel.java
      ├─ Alimento.java
      ├─ Animal.java
      ├─ Mamifero.java
      ├─ Ave.java
      ├─ Reptil.java
      ├─ Leao.java
      ├─ Aguia.java
      ├─ Cobra.java
      └─ Zoologico.java
```

## ✅ O que foi aplicado
- **Encapsulamento**: todos os atributos são **privados**; acesso via **getters/setters** (com validações simples).
- **Herança**: `Mamifero`, `Ave`, `Reptil` herdam de `Animal`.
- **Polimorfismo**: `emitirSom()` e `mover()` são sobrescritos nas subclasses.
- **Interface**: `Alimentavel` (métodos `comer` e `beber`) implementada por `Leao`, `Aguia`, `Cobra`.
- **Sobrecarga**: método `alimentar(...)` **sobrecarregado** (quantidade, tipo+quantidade, e objeto `Alimento`).

## 🧪 O que o `main` demonstra
- Criação de uma coleção `ArrayList<Animal>` com diferentes animais.
- Laço polimórfico chamando `emitirSom()` e `mover()`.
- Uso de `instanceof` para acionar comportamentos de `Alimentavel`.
- Exemplos de **sobrecarga** com `Leao#alimentar(...)`.

Bom estudo! ✨
